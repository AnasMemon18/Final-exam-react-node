import React, { useEffect, useState } from "react";
import Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';

import Navbar from "../Navbar/Navbar";

const User = () => {
    return (
        <div>
            <Navbar />
        </div>
    )
}

export default User