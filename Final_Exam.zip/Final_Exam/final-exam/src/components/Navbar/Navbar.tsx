import React, { FC } from 'react';
import { render } from 'react-dom'
import Highcharts from 'highcharts'
import HighchartsReact from 'highcharts-react-official'

//mui material
// import Grid from '@mui/material/Grid';

// prime react
import { Menubar } from 'primereact/menubar';
import { InputText } from 'primereact/inputtext';
import "primereact/resources/themes/lara-light-indigo/theme.css";
import "primereact/resources/primereact.min.css";
import 'primeicons/primeicons.css';

import { useNavigate } from 'react-router-dom';


const options = {
    title: {
        text: 'My chart'
    },
    series: [{
        data: [1, 2, 3]
    }]
}


const Dashboard: FC<any> = () => {
    const navigate = useNavigate();

    const handleMenuItemClick = (path: string) => {
      navigate(path);
    };

    const items = [
        {
            label: 'Dashboard',
            command: () => handleMenuItemClick('/'),
            
        },
     
    ];

    const start = <img alt="logo" src="https://primefaces.org/cdn/primereact/images/logo.png" height="40" className="mr-2"></img>;
    const end = <InputText placeholder="Search" type="text" className="w-full" />;

    return (
        <div>
            <Menubar model={items} start={start} end={end} />
            {/* <Grid container spacing={2} justifyContent="center"
                alignItems="center" style={{marginTop:'10px'}}>
                <Grid item xs={8}>
                    <HighchartsReact
                        highcharts={Highcharts}
                        options={options}
                    />
                </Grid>
            </Grid> */}

        </div>
    );
};

export default Dashboard;