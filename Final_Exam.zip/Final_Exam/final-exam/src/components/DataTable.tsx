import React, { useState, useEffect } from 'react';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Card } from 'primereact/card';
import { UserService } from './service/userService';
import { Paginator } from 'primereact/paginator';

interface Users {
  name: string;
  username: string;
  email: string;
  dob: Date;
  no_of_companies: number;
  status: string;
  created_at: Date;
}

export default function RemovableSortDemo() {
  const [users, setUsers] = useState<Users[]>([]);
  const [first, setFirst] = useState(0);
  const [rows, setRows] = useState(5);
  const [totalRecords, setTotalRecords] = useState(0);

  useEffect(() => {
    UserService.getUsersMini().then((data) => {
      setUsers(data);
      setTotalRecords(data.length);
    });
  }, []);

  const onPageChange = (event: { first: number; rows: number }) => {
    setFirst(event.first);
    setRows(event.rows);
  };

  return (
    <Card className="p-mb-4">
      <div style={{ maxHeight: '450px', overflowY: 'auto' }}>
        <DataTable
          value={users.slice(first, first + rows)}
          removableSort
          tableStyle={{ minWidth: '50rem' }}
          scrollable
        >
          <Column field="id" header="Id" sortable style={{ width: '25%' }} />
          <Column field="name" header="Name" sortable style={{ width: '25%' }} />
          <Column field="username" header="Username" sortable style={{ width: '25%' }} />
          <Column field="dob" header="Date Of Birth" sortable style={{ width: '25%' }} />
          <Column
            field="no_of_companies"
            header="Number Of Companies"
            sortable
            style={{ width: '25%' }}
          />
          <Column field="status" header="Status" sortable style={{ width: '25%' }} />
        </DataTable>
        <Paginator
          first={first}
          rows={rows}
          totalRecords={totalRecords}
          rowsPerPageOptions={[5, 10, 20]}
          onPageChange={onPageChange}
        />
      </div>
    </Card>
  );
}
