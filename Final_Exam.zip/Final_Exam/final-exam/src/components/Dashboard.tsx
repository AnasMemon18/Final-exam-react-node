import React, { useEffect, useState } from "react";
import Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';
import { Card } from 'primereact/card';

import Navbar from "./Navbar/Navbar";
import DataTable from "./DataTable";

const Dashboard = () => {
    const [status, setStatus] = useState({ active: 0, inactive: 0, disabled: 0 });
    const [users, setUsers] = useState();

    const getUsersStatus = () => {
        fetch('http://localhost:5000/getUsersStatus')
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    setStatus({
                        active: data.data[0].active,
                        inactive: data.data[1].inactive,
                        disabled: data.data[2].disabled,
                    });
                }
            })
            .catch(err => {
                console.log(err);
            });
    }

    const getUsers = () => {
        fetch('http://localhost:5000/getUsers')
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    console.log("Data getusers: ", data)
                }
            })
            .catch(err => {
                console.log(err);
            });
    }

    useEffect(() => {
        getUsersStatus();
    }, []);

    const options = {
        chart: {
            type: 'pie'
        },
        title: {
            text: 'Status of users'
        },
        plotOptions: {
            pie: {
                colors: ['#068DA9', '#F2D8D8', '#545B77'], // Custom colors
            },
        },
        series: [
            {
                data: [
                    { name: 'Active', y: status.active },
                    { name: 'Inactive', y: status.inactive },
                    { name: 'Disabled', y: status.disabled }
                ]
            }
        ]
    };

    const options2 = {
        chart: {
            type: 'line'
        },
        title: {
            text: 'Status of users',
            style: {
                fontSize: '18px',
                fontWeight: 'bold',
                fontFamily: 'Lucida Console',
                color: '#8B0000'
            }
        },
        series: [
            {
                data: [
                    { name: 'Active', y: status.active },
                    { name: 'Inactive', y: status.inactive },
                    { name: 'Disabled', y: status.disabled }
                ],
                name: '2023',
                color: 'red',
                label: {
                    style: {
                        fontSize: '17px', // Change the font size here
                        fontFamily: 'Arial' // Change the font family here
                    }
                }
            }
        ]
    };

    useEffect(() => {
        console.log("Data: ", status.active);
        options.series[0].data = [
            { name: 'Active', y: status.active },
            { name: 'Inactive', y: status.inactive },
            { name: 'Disabled', y: status.disabled }
        ];
        options2.series[0].data = [
            { name: 'Active', y: status.active },
            { name: 'Inactive', y: status.inactive },
            { name: 'Disabled', y: status.disabled }
        ];
    }, [status]);

    return (
        <div>
            <Navbar />
            <div className="p-grid p-dir-col p-nogutter">

                <div className="p-col-12 p-md-6">
                    <Card className="custom-card" title="Pie Chart" style={{ padding: '1rem', marginBottom: '1rem' }}>
                        <HighchartsReact highcharts={Highcharts} options={options} />
                    </Card>
                </div>

                <div className="p-col-12 p-md-6">
                    <Card className="custom-card" title="Line Chart" style={{ padding: '1rem', marginBottom: '1rem' }}>
                        <HighchartsReact highcharts={Highcharts} options={options2} />
                    </Card>
                </div>

                <div className="p-col-12 p-md-6">
                    <DataTable />
                </div>

            </div>
        </div>
    );
};

export default Dashboard;