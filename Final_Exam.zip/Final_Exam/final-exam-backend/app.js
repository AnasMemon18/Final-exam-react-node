const express = require("express");
const bodyParser  = require("body-parser");
const cors = require("cors");
const routes = require("./routes/routes");
const sequelize = require('./util/database');

const User = require('./models/user');


const app = express();

app.use(bodyParser.json());
app.use(cors());
app.use(routes);

sequelize
    .sync()
    .then(result=>{
    })
    .catch(err=>{
        console.log(err)
    })

app.listen(5000, ()=> { console.log("Server started on port 5000.")});