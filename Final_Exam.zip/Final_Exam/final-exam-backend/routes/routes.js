const express = require("express");
const userController = require("../controller/user_controller")
const router = express.Router();

router.get('/getUsersStatus', userController.getUsersStatus);

router.get('/getUsers',  userController.getUsers);

module.exports = router;