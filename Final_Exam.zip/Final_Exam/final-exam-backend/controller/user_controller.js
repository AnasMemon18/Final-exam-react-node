const User = require("../models/user");

const getUsersStatus = (req, res, next) => {

    var activeUser = 0
    var inactiveUser = 0
    var disabledUser = 0
    var data = []

    try {
        User.findAll()
          .then((result) => {
            for(let i=0; i< result.length; i++){
                if(result[i].status == "active"){
                    activeUser+=1
                }
                if(result[i].status == "inactive"){
                    inactiveUser+=1
                }
                if(result[i].status == "disabled"){
                    disabledUser+=1
                }
            }
            data.push({active:activeUser});
            data.push({inactive:inactiveUser});
            data.push({disabled:disabledUser});

            res.json({status:200, msg:"Data fetched successfully!", data:data})
          })
          .catch((err) => {
            throw err;
          });
      } catch (err) {
       console.log(err);
      }
}



const getUsers = (req, res, next) => {
    try{
        User.findAll().then(result => {
            res.json({status:200, data:result})
        })
    }
    catch(err){
        console.log(err)
    }
}
module.exports = {getUsersStatus, getUsers}